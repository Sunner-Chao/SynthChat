use std::time::Duration;

use reqwest::header::{HeaderMap, HeaderValue, AUTHORIZATION, CONTENT_TYPE};
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};

use crate::{
    error::{AppError, AppResult},
    models::{ChatMessage, LlmProvider, Persona},
};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WireMessage {
    pub role: String,
    pub content: String,
}

#[derive(Debug, Clone)]
pub struct LlmFailoverAttempt {
    pub provider_id: String,
    pub kind: String,
    pub message: String,
}

#[derive(Debug, Clone)]
pub struct LlmReply {
    pub content: String,
    pub prompt_tokens: usize,
    pub completion_tokens: usize,
    pub cache_read_tokens: usize,
    pub cache_write_tokens: usize,
    pub reasoning_tokens: usize,
    pub provider_id: Option<String>,
    pub provider_type: Option<String>,
    pub model: Option<String>,
    pub base_url: Option<String>,
    pub estimated_cost_usd: Option<f64>,
    pub cost_status: Option<String>,
    pub cost_source: Option<String>,
    pub rate_limit_state: Option<Value>,
    pub failover_attempts: Vec<LlmFailoverAttempt>,
}

pub async fn complete_chat(
    provider: &LlmProvider,
    persona: &Persona,
    system_prompt: String,
    history: Vec<ChatMessage>,
    user_content: &str,
) -> AppResult<LlmReply> {
    if provider.provider_type == "echo"
        || (provider.base_url.trim().is_empty() && !is_gemini_compatible(provider))
    {
        return Ok(echo_reply(user_content, history.len()));
    }

    if is_anthropic_compatible(provider) {
        return complete_anthropic_compatible(provider, persona, system_prompt, history).await;
    }
    if is_gemini_compatible(provider) {
        return complete_gemini_compatible(provider, persona, system_prompt, history).await;
    }

    let model = if !persona.llm_model.trim().is_empty() {
        persona.llm_model.trim()
    } else {
        provider.model.trim()
    };
    let cache_policy = prompt_cache_policy(provider, model);
    let messages = build_openai_wire_messages(system_prompt, history, cache_policy.as_ref());
    let url = chat_url(provider);
    let api_key = resolve_api_key(provider);

    let mut headers = HeaderMap::new();
    headers.insert(CONTENT_TYPE, HeaderValue::from_static("application/json"));
    if let Some(key) = api_key {
        let value = HeaderValue::from_str(&format!("Bearer {key}"))
            .map_err(|e| AppError::Llm(format!("invalid authorization header: {e}")))?;
        headers.insert(AUTHORIZATION, value);
    }

    let body = json!({
        "model": model,
        "messages": messages,
        "temperature": persona.temperature,
        "max_tokens": persona.max_tokens
    });

    let client = reqwest::Client::builder()
        .timeout(Duration::from_secs(provider.timeout_seconds.max(1)))
        .default_headers(headers)
        .build()
        .map_err(|e| AppError::Llm(e.to_string()))?;

    let response = client
        .post(url)
        .json(&body)
        .send()
        .await
        .map_err(|e| AppError::Llm(e.to_string()))?;

    let status = response.status();
    let response_headers = response.headers().clone();
    let text = response
        .text()
        .await
        .map_err(|e| AppError::Llm(format!("failed to read llm response: {e}")))?;

    if !status.is_success() {
        return Err(AppError::Llm(format!(
            "provider returned {status}: {}",
            response_preview(&text)
        )));
    }

    let payload: Value = match serde_json::from_str(&text) {
        Ok(payload) => payload,
        Err(error) => {
            if let Some(reply) = parse_openai_sse(&text) {
                return Ok(with_reply_metadata(reply, provider, model, &response_headers));
            }
            return Err(AppError::Llm(format!(
                "invalid llm response ({status}): {error}; body: {}",
                response_preview(&text)
            )));
        }
    };

    parse_openai_compatible(payload).map(|reply| with_reply_metadata(reply, provider, model, &response_headers))
}

pub async fn complete_text_prompt(
    provider: &LlmProvider,
    persona: &Persona,
    system_prompt: String,
    user_prompt: String,
) -> AppResult<LlmReply> {
    let message = ChatMessage::new(
        "__planner__".into(),
        "user",
        user_prompt.clone(),
        "internal",
    );
    complete_chat(
        provider,
        persona,
        system_prompt,
        vec![message],
        &user_prompt,
    )
    .await
}

async fn complete_anthropic_compatible(
    provider: &LlmProvider,
    persona: &Persona,
    system_prompt: String,
    history: Vec<ChatMessage>,
) -> AppResult<LlmReply> {
    let model = if !persona.llm_model.trim().is_empty() {
        persona.llm_model.trim()
    } else {
        provider.model.trim()
    };
    let url = anthropic_messages_url(provider);
    let api_key = resolve_api_key(provider);

    let mut headers = HeaderMap::new();
    headers.insert(CONTENT_TYPE, HeaderValue::from_static("application/json"));
    headers.insert("anthropic-version", HeaderValue::from_static("2023-06-01"));
    if let Some(key) = api_key {
        let bearer = HeaderValue::from_str(&format!("Bearer {key}"))
            .map_err(|e| AppError::Llm(format!("invalid authorization header: {e}")))?;
        let x_api_key = HeaderValue::from_str(&key)
            .map_err(|e| AppError::Llm(format!("invalid x-api-key header: {e}")))?;
        headers.insert(AUTHORIZATION, bearer);
        headers.insert("x-api-key", x_api_key);
    }

    let messages: Vec<WireMessage> = history
        .into_iter()
        .filter_map(|item| sanitized_wire_message(item, true))
        .collect();

    let cache_policy = prompt_cache_policy(provider, model);
    let system_value = anthropic_system_value(system_prompt, cache_policy.as_ref());
    let body = json!({
        "model": model,
        "system": system_value,
        "messages": messages,
        "temperature": persona.temperature,
        "max_tokens": persona.max_tokens,
        "stream": false
    });

    let client = reqwest::Client::builder()
        .timeout(Duration::from_secs(provider.timeout_seconds.max(1)))
        .default_headers(headers)
        .build()
        .map_err(|e| AppError::Llm(e.to_string()))?;

    let response = client
        .post(url)
        .json(&body)
        .send()
        .await
        .map_err(|e| AppError::Llm(e.to_string()))?;

    let status = response.status();
    let response_headers = response.headers().clone();
    let text = response
        .text()
        .await
        .map_err(|e| AppError::Llm(format!("failed to read llm response: {e}")))?;

    if !status.is_success() {
        return Err(AppError::Llm(format!(
            "provider returned {status}: {}",
            response_preview(&text)
        )));
    }

    let payload: Value = serde_json::from_str(&text).map_err(|e| {
        AppError::Llm(format!(
            "invalid anthropic response ({status}): {e}; body: {}",
            response_preview(&text)
        ))
    })?;

    parse_anthropic_compatible(payload)
        .map(|reply| with_reply_metadata(reply, provider, model, &response_headers))
}

async fn complete_gemini_compatible(
    provider: &LlmProvider,
    persona: &Persona,
    system_prompt: String,
    history: Vec<ChatMessage>,
) -> AppResult<LlmReply> {
    let model = if !persona.llm_model.trim().is_empty() {
        persona.llm_model.trim()
    } else {
        provider.model.trim()
    };
    let url = gemini_generate_content_url(provider, model);
    let api_key = resolve_api_key(provider);

    let mut headers = HeaderMap::new();
    headers.insert(CONTENT_TYPE, HeaderValue::from_static("application/json"));
    if let Some(key) = api_key {
        let x_api_key = HeaderValue::from_str(&key)
            .map_err(|e| AppError::Llm(format!("invalid x-goog-api-key header: {e}")))?;
        let bearer = HeaderValue::from_str(&format!("Bearer {key}"))
            .map_err(|e| AppError::Llm(format!("invalid authorization header: {e}")))?;
        headers.insert("x-goog-api-key", x_api_key);
        headers.insert(AUTHORIZATION, bearer);
    }

    let contents = build_gemini_contents(history);
    let body = json!({
        "systemInstruction": {
            "parts": [{"text": system_prompt}]
        },
        "contents": contents,
        "generationConfig": {
            "temperature": persona.temperature,
            "maxOutputTokens": persona.max_tokens
        }
    });

    let client = reqwest::Client::builder()
        .timeout(Duration::from_secs(provider.timeout_seconds.max(1)))
        .default_headers(headers)
        .build()
        .map_err(|e| AppError::Llm(e.to_string()))?;

    let response = client
        .post(url)
        .json(&body)
        .send()
        .await
        .map_err(|e| AppError::Llm(e.to_string()))?;

    let status = response.status();
    let response_headers = response.headers().clone();
    let text = response
        .text()
        .await
        .map_err(|e| AppError::Llm(format!("failed to read gemini response: {e}")))?;

    if !status.is_success() {
        return Err(AppError::Llm(format!(
            "provider returned {status}: {}",
            response_preview(&text)
        )));
    }

    let payload: Value = serde_json::from_str(&text).map_err(|e| {
        AppError::Llm(format!(
            "invalid gemini response ({status}): {e}; body: {}",
            response_preview(&text)
        ))
    })?;

    parse_gemini_compatible(payload)
        .map(|reply| with_reply_metadata(reply, provider, model, &response_headers))
}

fn is_anthropic_compatible(provider: &LlmProvider) -> bool {
    let provider_type = provider.provider_type.to_lowercase();
    let preset = provider
        .preset
        .as_deref()
        .unwrap_or_default()
        .to_lowercase();
    let base_url = provider.base_url.to_lowercase();
    provider_type == "anthropic"
        || preset.contains("anthropic")
        || base_url.contains("/anthropic")
        || base_url.ends_with("/v1/messages")
}

fn is_gemini_compatible(provider: &LlmProvider) -> bool {
    let provider_type = provider.provider_type.to_lowercase();
    let preset = provider
        .preset
        .as_deref()
        .unwrap_or_default()
        .to_lowercase();
    let base_url = provider.base_url.to_lowercase();
    provider_type == "gemini"
        || preset.contains("google")
        || preset.contains("gemini")
        || base_url.contains("generativelanguage.googleapis.com")
        || base_url.ends_with(":generatecontent")
}

#[derive(Debug, Clone)]
struct PromptCachePolicy {
    native_layout: bool,
    ttl: String,
}

fn build_openai_wire_messages(
    system_prompt: String,
    history: Vec<ChatMessage>,
    cache_policy: Option<&PromptCachePolicy>,
) -> Vec<Value> {
    let mut system_content = sanitize_provider_text(&system_prompt);
    let mut conversation_messages = Vec::new();
    for item in history {
        if item.role == "system" {
            let content = sanitize_provider_text(&item.content);
            if !content.trim().is_empty() {
                if !system_content.trim().is_empty() {
                    system_content.push_str("\n\n");
                }
                system_content.push_str(&content);
            }
            continue;
        }
        if let Some(message) = sanitized_wire_message(item, false) {
            conversation_messages.push(json!({
                "role": message.role,
                "content": message.content,
            }));
        }
    }

    let mut system = json!({
        "role": "system",
        "content": system_content,
    });
    if let Some(policy) = cache_policy.filter(|policy| !policy.native_layout) {
        system["cache_control"] = cache_control_value(policy);
    }
    let mut messages = Vec::with_capacity(conversation_messages.len() + 1);
    messages.push(system);
    messages.extend(conversation_messages);
    messages
}

fn sanitized_wire_message(item: ChatMessage, anthropic: bool) -> Option<WireMessage> {
    let role = match item.role.as_str() {
        "user" => "user",
        "assistant" => {
            if anthropic {
                "assistant"
            } else {
                "assistant"
            }
        }
        _ => return None,
    };
    let content = sanitize_provider_text(&item.content);
    if content.trim().is_empty() {
        return None;
    }
    Some(WireMessage {
        role: role.into(),
        content,
    })
}

fn sanitize_provider_text(content: &str) -> String {
    let scrubbed = scrub_reasoning_blocks(content);
    scrubbed
        .chars()
        .map(|ch| {
            if ch.is_control() && !matches!(ch, '\n' | '\r' | '\t') {
                '\u{fffd}'
            } else {
                ch
            }
        })
        .collect::<String>()
        .trim()
        .to_string()
}

fn anthropic_system_value(system_prompt: String, cache_policy: Option<&PromptCachePolicy>) -> Value {
    if let Some(policy) = cache_policy.filter(|policy| policy.native_layout) {
        json!([{
            "type": "text",
            "text": system_prompt,
            "cache_control": cache_control_value(policy),
        }])
    } else {
        json!(system_prompt)
    }
}

fn cache_control_value(policy: &PromptCachePolicy) -> Value {
    let mut value = json!({"type": "ephemeral"});
    if policy.ttl == "1h" {
        value["ttl"] = json!("1h");
    }
    value
}

fn prompt_cache_policy(provider: &LlmProvider, model: &str) -> Option<PromptCachePolicy> {
    let mode = provider.prompt_cache_mode.trim().to_ascii_lowercase();
    if mode == "off" || mode == "disabled" || mode == "false" {
        return None;
    }
    let auto = auto_prompt_cache_policy(provider, model);
    let forced = matches!(mode.as_str(), "on" | "enabled" | "true" | "force");
    if !forced && auto.is_none() {
        return None;
    }
    let layout = provider.prompt_cache_layout.trim().to_ascii_lowercase();
    let native_layout = match layout.as_str() {
        "native" | "anthropic" | "content" => true,
        "envelope" | "openai" | "openrouter" => false,
        _ => auto.unwrap_or_else(|| is_anthropic_compatible(provider)),
    };
    Some(PromptCachePolicy {
        native_layout,
        ttl: normalized_prompt_cache_ttl(&provider.prompt_cache_ttl),
    })
}

fn auto_prompt_cache_policy(provider: &LlmProvider, model: &str) -> Option<bool> {
    let model_lower = model.to_ascii_lowercase();
    let provider_type = provider.provider_type.to_ascii_lowercase();
    let preset = provider
        .preset
        .as_deref()
        .unwrap_or_default()
        .to_ascii_lowercase();
    let base_url = provider.base_url.to_ascii_lowercase();
    let is_claude = model_lower.contains("claude");
    let is_qwen = model_lower.contains("qwen");
    let anthropic_wire = is_anthropic_compatible(provider);
    let native_anthropic =
        anthropic_wire && (provider_type == "anthropic" || host_matches(&base_url, "api.anthropic.com"));
    if native_anthropic {
        return Some(true);
    }
    if (host_matches(&base_url, "openrouter.ai") || base_url.contains("nousresearch"))
        && (is_claude || is_qwen)
    {
        return Some(false);
    }
    if anthropic_wire && is_claude {
        return Some(true);
    }
    if anthropic_wire
        && (provider_type.contains("minimax")
            || preset.contains("minimax")
            || host_matches(&base_url, "api.minimax.io")
            || host_matches(&base_url, "api.minimaxi.com"))
    {
        return Some(true);
    }
    if is_qwen
        && (provider_type.contains("opencode")
            || provider_type.contains("alibaba")
            || preset.contains("opencode")
            || preset.contains("alibaba"))
    {
        return Some(false);
    }
    None
}

fn normalized_prompt_cache_ttl(value: &str) -> String {
    if value.trim().eq_ignore_ascii_case("1h") {
        "1h".into()
    } else {
        "5m".into()
    }
}

fn host_matches(base_url: &str, expected: &str) -> bool {
    reqwest::Url::parse(base_url)
        .ok()
        .and_then(|url| url.host_str().map(|host| host.eq_ignore_ascii_case(expected)))
        .unwrap_or(false)
}

fn build_gemini_contents(history: Vec<ChatMessage>) -> Vec<Value> {
    history
        .into_iter()
        .filter_map(|item| {
            let role = match item.role.as_str() {
                "assistant" => "model",
                "user" => "user",
                _ => return None,
            };
            let content = sanitize_provider_text(&item.content);
            if content.trim().is_empty() {
                return None;
            }
            Some(json!({
                "role": role,
                "parts": [{"text": content}]
            }))
        })
        .collect()
}

fn chat_url(provider: &LlmProvider) -> String {
    let base = provider.base_url.trim().trim_end_matches('/');
    if provider.append_chat_path && is_ollama_root_url(base) {
        return format!("{base}/v1/chat/completions");
    }
    if provider.append_chat_path && !base.ends_with("/chat/completions") {
        format!("{base}/chat/completions")
    } else {
        base.to_string()
    }
}

fn is_ollama_root_url(base: &str) -> bool {
    let value = base.to_lowercase();
    (value.contains("127.0.0.1:11434")
        || value.contains("localhost:11434")
        || value.contains("[::1]:11434"))
        && !value.ends_with("/v1")
        && !value.ends_with("/api")
        && !value.ends_with("/chat/completions")
}

fn anthropic_messages_url(provider: &LlmProvider) -> String {
    let base = provider.base_url.trim().trim_end_matches('/');
    if base.ends_with("/v1/messages") {
        base.to_string()
    } else if base.ends_with("/v1") {
        format!("{base}/messages")
    } else if provider.append_chat_path {
        format!("{base}/v1/messages")
    } else {
        base.to_string()
    }
}

fn gemini_generate_content_url(provider: &LlmProvider, model: &str) -> String {
    let base = provider.base_url.trim().trim_end_matches('/');
    if base.is_empty() {
        return format!(
            "https://generativelanguage.googleapis.com/v1beta/models/{}:generateContent",
            gemini_model_id(model)
        );
    }
    if base.to_lowercase().ends_with(":generatecontent") {
        base.to_string()
    } else if base.ends_with("/v1") || base.ends_with("/v1beta") {
        format!("{base}/models/{}:generateContent", gemini_model_id(model))
    } else if provider.append_chat_path {
        format!("{base}/models/{}:generateContent", gemini_model_id(model))
    } else {
        base.to_string()
    }
}

fn gemini_model_id(model: &str) -> String {
    let value = model.trim();
    let value = value.strip_prefix("models/").unwrap_or(value);
    if value.is_empty() {
        "gemini-2.0-flash".into()
    } else {
        value.to_string()
    }
}

fn resolve_api_key(provider: &LlmProvider) -> Option<String> {
    if let Some(key) = provider
        .api_key
        .as_ref()
        .map(|v| v.trim())
        .filter(|v| !v.is_empty())
    {
        return Some(key.to_string());
    }
    let env_name = provider.api_key_env.trim();
    if env_name.is_empty() {
        None
    } else if looks_like_inline_api_key(env_name) {
        Some(env_name.to_string())
    } else {
        std::env::var(env_name)
            .ok()
            .filter(|v| !v.trim().is_empty())
    }
}

fn looks_like_inline_api_key(value: &str) -> bool {
    value.starts_with("sk-")
        || value.starts_with("sk_")
        || value.starts_with("pk-")
        || value.starts_with("AIza")
        || value.len() > 48 && !value.chars().any(char::is_whitespace)
}

fn parse_openai_sse(text: &str) -> Option<LlmReply> {
    let mut content = String::new();
    let mut prompt_tokens = 0;
    let mut completion_tokens = 0;

    for line in text.lines() {
        let line = line.trim();
        let Some(data) = line.strip_prefix("data:") else {
            continue;
        };
        let data = data.trim();
        if data.is_empty() || data == "[DONE]" {
            continue;
        }
        let Ok(payload) = serde_json::from_str::<Value>(data) else {
            continue;
        };
        if let Some(delta) = payload
            .pointer("/choices/0/delta/content")
            .and_then(Value::as_str)
            .or_else(|| {
                payload
                    .pointer("/choices/0/message/content")
                    .and_then(Value::as_str)
            })
        {
            content.push_str(delta);
        }
        if prompt_tokens == 0 {
            prompt_tokens = payload
                .pointer("/usage/prompt_tokens")
                .and_then(Value::as_u64)
                .unwrap_or(0) as usize;
        }
        if completion_tokens == 0 {
            completion_tokens = payload
                .pointer("/usage/completion_tokens")
                .and_then(Value::as_u64)
                .unwrap_or(0) as usize;
        }
    }

    let content = scrub_reasoning_blocks(&content);
    if content.trim().is_empty() {
        None
    } else {
        Some(LlmReply {
            prompt_tokens,
            completion_tokens: if completion_tokens == 0 {
                estimate_tokens(&content)
            } else {
                completion_tokens
            },
            cache_read_tokens: 0,
            cache_write_tokens: 0,
            reasoning_tokens: 0,
            content,
            provider_id: None,
            provider_type: None,
            model: None,
            base_url: None,
            estimated_cost_usd: None,
            cost_status: None,
            cost_source: None,
            rate_limit_state: None,
            failover_attempts: Vec::new(),
        })
    }
}

fn parse_openai_compatible(payload: Value) -> AppResult<LlmReply> {
    let content_value = payload
        .pointer("/choices/0/message/content")
        .or_else(|| payload.pointer("/message/content"))
        .ok_or_else(|| AppError::Llm(format!("missing assistant content: {payload}")))?;
    let content = extract_openai_message_content(content_value)
        .ok_or_else(|| AppError::Llm(format!("openai response has no text content: {payload}")))?;
    let content = scrub_reasoning_blocks(&content);
    if content.trim().is_empty() {
        return Err(AppError::Llm(format!(
            "openai response only contained hidden reasoning content: {payload}"
        )));
    }

    let prompt_tokens = payload
        .pointer("/usage/prompt_tokens")
        .and_then(Value::as_u64)
        .unwrap_or(0) as usize;
    let completion_tokens = payload
        .pointer("/usage/completion_tokens")
        .and_then(Value::as_u64)
        .unwrap_or_else(|| estimate_tokens(&content) as u64) as usize;
    let cache_read_tokens = payload
        .pointer("/usage/prompt_tokens_details/cached_tokens")
        .and_then(Value::as_u64)
        .unwrap_or(0) as usize;
    let reasoning_tokens = payload
        .pointer("/usage/completion_tokens_details/reasoning_tokens")
        .and_then(Value::as_u64)
        .unwrap_or(0) as usize;

    Ok(LlmReply {
        content,
        prompt_tokens,
        completion_tokens,
        cache_read_tokens,
        cache_write_tokens: 0,
        reasoning_tokens,
        provider_id: None,
        provider_type: None,
        model: None,
        base_url: None,
        estimated_cost_usd: None,
        cost_status: None,
        cost_source: None,
        rate_limit_state: None,
        failover_attempts: Vec::new(),
    })
}

fn extract_openai_message_content(value: &Value) -> Option<String> {
    if let Some(text) = value.as_str() {
        return (!text.trim().is_empty()).then(|| text.to_string());
    }
    let parts = value.as_array()?;
    let text = parts
        .iter()
        .filter_map(|part| {
            part.get("text")
                .and_then(Value::as_str)
                .or_else(|| part.pointer("/text/value").and_then(Value::as_str))
                .or_else(|| part.pointer("/content/text").and_then(Value::as_str))
        })
        .filter(|part| !part.trim().is_empty())
        .collect::<Vec<_>>()
        .join("\n\n");
    (!text.trim().is_empty()).then_some(text)
}

fn parse_gemini_compatible(payload: Value) -> AppResult<LlmReply> {
    let candidates = payload
        .get("candidates")
        .and_then(Value::as_array)
        .ok_or_else(|| AppError::Llm(format!("missing gemini candidates: {payload}")))?;

    let content = candidates
        .iter()
        .flat_map(|candidate| {
            candidate
                .pointer("/content/parts")
                .and_then(Value::as_array)
                .into_iter()
                .flatten()
        })
        .filter_map(|part| part.get("text").and_then(Value::as_str))
        .filter(|text| !text.trim().is_empty())
        .collect::<Vec<_>>()
        .join("\n\n");
    let content = scrub_reasoning_blocks(&content);

    if content.trim().is_empty() {
        return Err(AppError::Llm(format!(
            "gemini response has no text content: {payload}"
        )));
    }

    let prompt_tokens = payload
        .pointer("/usageMetadata/promptTokenCount")
        .and_then(Value::as_u64)
        .unwrap_or(0) as usize;
    let completion_tokens = payload
        .pointer("/usageMetadata/candidatesTokenCount")
        .and_then(Value::as_u64)
        .unwrap_or_else(|| estimate_tokens(&content) as u64) as usize;
    let cached_content_tokens = payload
        .pointer("/usageMetadata/cachedContentTokenCount")
        .and_then(Value::as_u64)
        .unwrap_or(0) as usize;
    let thoughts_tokens = payload
        .pointer("/usageMetadata/thoughtsTokenCount")
        .and_then(Value::as_u64)
        .unwrap_or(0) as usize;

    Ok(LlmReply {
        content,
        prompt_tokens,
        completion_tokens,
        cache_read_tokens: cached_content_tokens,
        cache_write_tokens: 0,
        reasoning_tokens: thoughts_tokens,
        provider_id: None,
        provider_type: None,
        model: None,
        base_url: None,
        estimated_cost_usd: None,
        cost_status: None,
        cost_source: None,
        rate_limit_state: None,
        failover_attempts: Vec::new(),
    })
}

fn parse_anthropic_compatible(payload: Value) -> AppResult<LlmReply> {
    let content_blocks = payload
        .get("content")
        .and_then(Value::as_array)
        .ok_or_else(|| AppError::Llm(format!("missing anthropic content: {payload}")))?;

    let content = content_blocks
        .iter()
        .filter_map(|block| {
            let ty = block.get("type").and_then(Value::as_str).unwrap_or("");
            if ty == "text" || block.get("text").is_some() {
                block.get("text").and_then(Value::as_str)
            } else {
                None
            }
        })
        .collect::<Vec<_>>()
        .join("\n\n");
    let content = scrub_reasoning_blocks(&content);

    if content.trim().is_empty() {
        return Err(AppError::Llm(format!(
            "anthropic response has no text content: {payload}"
        )));
    }

    let prompt_tokens = payload
        .pointer("/usage/input_tokens")
        .and_then(Value::as_u64)
        .unwrap_or(0) as usize;
    let completion_tokens = payload
        .pointer("/usage/output_tokens")
        .and_then(Value::as_u64)
        .unwrap_or_else(|| estimate_tokens(&content) as u64) as usize;
    let cache_read_tokens = payload
        .pointer("/usage/cache_read_input_tokens")
        .and_then(Value::as_u64)
        .unwrap_or(0) as usize;
    let cache_write_tokens = payload
        .pointer("/usage/cache_creation_input_tokens")
        .and_then(Value::as_u64)
        .unwrap_or(0) as usize;

    Ok(LlmReply {
        content,
        prompt_tokens,
        completion_tokens,
        cache_read_tokens,
        cache_write_tokens,
        reasoning_tokens: 0,
        provider_id: None,
        provider_type: None,
        model: None,
        base_url: None,
        estimated_cost_usd: None,
        cost_status: None,
        cost_source: None,
        rate_limit_state: None,
        failover_attempts: Vec::new(),
    })
}

fn response_preview(text: &str) -> String {
    let clean = text.replace('\n', " ").replace('\r', " ");
    clean.chars().take(500).collect()
}

fn scrub_reasoning_blocks(content: &str) -> String {
    let mut output = content.to_string();
    for tag in [
        "think",
        "thinking",
        "reasoning",
        "thought",
        "REASONING_SCRATCHPAD",
    ] {
        output = remove_closed_reasoning_pairs(&output, tag);
    }
    for tag in [
        "think",
        "thinking",
        "reasoning",
        "thought",
        "REASONING_SCRATCHPAD",
    ] {
        output = remove_unterminated_reasoning_blocks(&output, tag);
    }
    for tag in [
        "think",
        "thinking",
        "reasoning",
        "thought",
        "REASONING_SCRATCHPAD",
    ] {
        output = strip_reasoning_close_tags(&output, tag);
    }
    normalize_visible_assistant_text(&output)
}

fn remove_closed_reasoning_pairs(content: &str, tag: &str) -> String {
    let open = format!("<{tag}>");
    let close = format!("</{tag}>");
    let mut output = content.to_string();
    loop {
        let Some(open_idx) = find_ascii_case_insensitive(&output, &open, 0) else {
            break;
        };
        let close_search_start = open_idx + open.len();
        let Some(close_idx) = find_ascii_case_insensitive(&output, &close, close_search_start)
        else {
            break;
        };
        output.replace_range(open_idx..close_idx + close.len(), "");
    }
    output
}

fn remove_unterminated_reasoning_blocks(content: &str, tag: &str) -> String {
    let open = format!("<{tag}>");
    let close = format!("</{tag}>");
    let mut output = content.to_string();
    let mut cursor = 0usize;
    while let Some(open_idx) = find_ascii_case_insensitive(&output, &open, cursor) {
        if !reasoning_open_at_block_boundary(&output[..open_idx]) {
            cursor = open_idx + open.len();
            continue;
        }
        let close_search_start = open_idx + open.len();
        if let Some(close_idx) = find_ascii_case_insensitive(&output, &close, close_search_start) {
            output.replace_range(open_idx..close_idx + close.len(), "");
            cursor = open_idx;
        } else {
            output.truncate(open_idx);
            break;
        }
    }
    output
}

fn strip_reasoning_close_tags(content: &str, tag: &str) -> String {
    let close = format!("</{tag}>");
    let mut output = content.to_string();
    while let Some(close_idx) = find_ascii_case_insensitive(&output, &close, 0) {
        output.replace_range(close_idx..close_idx + close.len(), "");
    }
    output
}

fn find_ascii_case_insensitive(haystack: &str, needle: &str, start: usize) -> Option<usize> {
    if start >= haystack.len() {
        return None;
    }
    let haystack_lower = haystack[start..].to_ascii_lowercase();
    let needle_lower = needle.to_ascii_lowercase();
    haystack_lower.find(&needle_lower).map(|idx| start + idx)
}

fn reasoning_open_at_block_boundary(prefix: &str) -> bool {
    if prefix.trim().is_empty() {
        return true;
    }
    match prefix.rfind('\n') {
        Some(index) => prefix[index + 1..].trim().is_empty(),
        None => false,
    }
}

fn normalize_visible_assistant_text(value: &str) -> String {
    let mut lines = value
        .lines()
        .map(str::trim_end)
        .collect::<Vec<_>>();
    while lines.first().map(|line| line.trim().is_empty()).unwrap_or(false) {
        lines.remove(0);
    }
    while lines.last().map(|line| line.trim().is_empty()).unwrap_or(false) {
        lines.pop();
    }
    let mut output = lines.join("\n");
    while output.contains("\n\n\n") {
        output = output.replace("\n\n\n", "\n\n");
    }
    output.trim().to_string()
}

fn echo_reply(user_content: &str, history_len: usize) -> LlmReply {
    let content = format!(
        "收到：{}\n\n当前 Rust 对话链已接管会话，已读取最近 {} 条上下文。配置 LLM Provider 后会切换为真实模型回复。",
        user_content,
        history_len.saturating_sub(1)
    );
    LlmReply {
        prompt_tokens: estimate_tokens(user_content),
        completion_tokens: estimate_tokens(&content),
        cache_read_tokens: 0,
        cache_write_tokens: 0,
        reasoning_tokens: 0,
        content,
        provider_id: Some("local-echo".into()),
        provider_type: Some("echo".into()),
        model: Some("echo".into()),
        base_url: None,
        estimated_cost_usd: Some(0.0),
        cost_status: Some("included".into()),
        cost_source: Some("none".into()),
        rate_limit_state: None,
        failover_attempts: Vec::new(),
    }
}

fn with_reply_metadata(
    mut reply: LlmReply,
    provider: &LlmProvider,
    model: &str,
    headers: &HeaderMap,
) -> LlmReply {
    reply.provider_id = Some(provider.id.clone());
    reply.provider_type = Some(provider.provider_type.clone());
    reply.model = Some(model.to_string());
    reply.base_url = if provider.base_url.trim().is_empty() {
        None
    } else {
        Some(provider.base_url.clone())
    };
    reply.rate_limit_state = parse_rate_limit_headers(headers, &provider.provider_type);
    let (amount, status, source) = estimate_usage_cost(
        &provider.provider_type,
        model,
        reply.prompt_tokens,
        reply.completion_tokens,
        reply.cache_read_tokens,
        reply.cache_write_tokens,
    );
    reply.estimated_cost_usd = amount;
    reply.cost_status = Some(status.into());
    reply.cost_source = Some(source.into());
    reply
}

fn parse_rate_limit_headers(headers: &HeaderMap, provider: &str) -> Option<Value> {
    let has_any = headers
        .keys()
        .any(|key| key.as_str().to_ascii_lowercase().starts_with("x-ratelimit-"));
    if !has_any {
        return None;
    }

    let bucket = |resource: &str, suffix: &str| {
        let tag = format!("{resource}{suffix}");
        let limit = header_u64(headers, &format!("x-ratelimit-limit-{tag}"));
        let remaining = header_u64(headers, &format!("x-ratelimit-remaining-{tag}"));
        let reset_seconds = header_f64(headers, &format!("x-ratelimit-reset-{tag}"));
        let used = limit.saturating_sub(remaining);
        let usage_pct = if limit == 0 {
            0.0
        } else {
            (used as f64 / limit as f64) * 100.0
        };
        json!({
            "limit": limit,
            "remaining": remaining,
            "used": used,
            "usagePct": usage_pct,
            "resetSeconds": reset_seconds
        })
    };

    Some(json!({
        "provider": provider,
        "capturedAt": crate::models::now_iso(),
        "requestsMin": bucket("requests", ""),
        "requestsHour": bucket("requests", "-1h"),
        "tokensMin": bucket("tokens", ""),
        "tokensHour": bucket("tokens", "-1h")
    }))
}

fn header_u64(headers: &HeaderMap, name: &str) -> u64 {
    header_text(headers, name)
        .and_then(|value| value.parse::<f64>().ok())
        .map(|value| value.max(0.0) as u64)
        .unwrap_or(0)
}

fn header_f64(headers: &HeaderMap, name: &str) -> f64 {
    header_text(headers, name)
        .and_then(|value| value.parse::<f64>().ok())
        .unwrap_or(0.0)
}

fn header_text(headers: &HeaderMap, name: &str) -> Option<String> {
    headers
        .get(name)
        .and_then(|value| value.to_str().ok())
        .map(str::to_string)
}

fn estimate_usage_cost(
    provider_type: &str,
    model: &str,
    input_tokens: usize,
    output_tokens: usize,
    cache_read_tokens: usize,
    cache_write_tokens: usize,
) -> (Option<f64>, &'static str, &'static str) {
    let Some((input_per_million, output_per_million, cache_read_per_million, cache_write_per_million)) =
        pricing_for_model(provider_type, model)
    else {
        return (None, "unknown", "none");
    };
    let input = input_tokens.saturating_sub(cache_read_tokens + cache_write_tokens) as f64;
    let amount = (input * input_per_million
        + output_tokens as f64 * output_per_million
        + cache_read_tokens as f64 * cache_read_per_million
        + cache_write_tokens as f64 * cache_write_per_million)
        / 1_000_000.0;
    (Some(amount), "estimated", "official_docs_snapshot")
}

fn pricing_for_model(provider_type: &str, model: &str) -> Option<(f64, f64, f64, f64)> {
    let provider = provider_type.to_ascii_lowercase();
    let model = model.to_ascii_lowercase();
    let openai_like = provider.contains("openai") || provider.contains("compatible");
    if openai_like || provider.contains("openrouter") {
        if model.contains("gpt-4o-mini") {
            return Some((0.15, 0.60, 0.075, 0.0));
        }
        if model.contains("gpt-4o") {
            return Some((2.50, 10.00, 1.25, 0.0));
        }
        if model.contains("gpt-4.1-mini") {
            return Some((0.40, 1.60, 0.10, 0.0));
        }
        if model.contains("gpt-4.1") {
            return Some((2.00, 8.00, 0.50, 0.0));
        }
    }
    if provider.contains("anthropic") || model.contains("claude") {
        if model.contains("haiku") {
            return Some((1.00, 5.00, 0.10, 1.25));
        }
        if model.contains("sonnet") {
            return Some((3.00, 15.00, 0.30, 3.75));
        }
        if model.contains("opus") {
            return Some((5.00, 25.00, 0.50, 6.25));
        }
    }
    if provider.contains("gemini") || provider.contains("google") || model.contains("gemini") {
        if model.contains("flash") {
            return Some((0.10, 0.40, 0.025, 0.0));
        }
        if model.contains("pro") {
            return Some((1.25, 5.00, 0.31, 0.0));
        }
    }
    None
}

pub fn estimate_tokens(text: &str) -> usize {
    let chars = text.chars().count();
    if chars == 0 {
        0
    } else {
        (chars / 3).max(1)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use reqwest::header::HeaderMap;

    #[test]
    fn rate_limit_headers_parse_into_usage_buckets() {
        let mut headers = HeaderMap::new();
        headers.insert("x-ratelimit-limit-requests", "100".parse().unwrap());
        headers.insert("x-ratelimit-remaining-requests", "80".parse().unwrap());
        headers.insert("x-ratelimit-reset-requests", "30".parse().unwrap());
        headers.insert("x-ratelimit-limit-tokens-1h", "1000000".parse().unwrap());
        headers.insert("x-ratelimit-remaining-tokens-1h", "750000".parse().unwrap());
        headers.insert("x-ratelimit-reset-tokens-1h", "3600".parse().unwrap());

        let state = parse_rate_limit_headers(&headers, "openai-compatible").unwrap();

        assert_eq!(state["requestsMin"]["limit"], 100);
        assert_eq!(state["requestsMin"]["used"], 20);
        assert_eq!(state["tokensHour"]["remaining"], 750000);
    }

    #[test]
    fn known_model_usage_cost_is_estimated() {
        let (amount, status, source) =
            estimate_usage_cost("openai-compatible", "gpt-4o-mini", 1_000_000, 500_000, 0, 0);

        assert_eq!(status, "estimated");
        assert_eq!(source, "official_docs_snapshot");
        assert!((amount.unwrap() - 0.45).abs() < 0.000001);
    }

    #[test]
    fn reasoning_blocks_are_scrubbed_from_visible_text() {
        let scrubbed = scrub_reasoning_blocks(
            "先说一句。\n<think>hidden plan</think>\n\n<REASONING_SCRATCHPAD>secret",
        );
        assert_eq!(scrubbed, "先说一句。");

        let inline = scrub_reasoning_blocks("普通说明：请不要手写 <think> 标签。");
        assert_eq!(inline, "普通说明：请不要手写 <think> 标签。");
    }

    #[test]
    fn openai_parser_strips_reasoning_blocks() {
        let reply = parse_openai_compatible(json!({
            "choices": [{
                "message": {
                    "content": "<think>do not show</think>\n最终回答"
                }
            }],
            "usage": {
                "prompt_tokens": 10,
                "completion_tokens": 8
            }
        }))
        .unwrap();

        assert_eq!(reply.content, "最终回答");
    }

    #[test]
    fn wire_message_builder_sanitizes_history_before_provider_send() {
        let messages = build_openai_wire_messages(
            "root system".into(),
            vec![
                ChatMessage::new(
                    "conv".into(),
                    "system",
                    "extra system".into(),
                    "test",
                ),
                ChatMessage::new(
                    "conv".into(),
                    "assistant",
                    "<think>hidden only</think>".into(),
                    "test",
                ),
                ChatMessage::new(
                    "conv".into(),
                    "user",
                    "visible\u{0007}text".into(),
                    "test",
                ),
            ],
            None,
        );

        assert_eq!(messages.len(), 2);
        assert_eq!(messages[0]["role"], "system");
        assert_eq!(messages[0]["content"], "root system\n\nextra system");
        assert_eq!(messages[1]["role"], "user");
        assert_eq!(messages[1]["content"], "visible\u{fffd}text");
    }
}

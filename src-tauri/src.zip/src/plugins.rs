use std::{
    collections::{HashMap, HashSet},
    fs,
    path::{Path, PathBuf},
};

use serde_json::Value;

use crate::{error::AppResult, models::PluginSummary, store::AppStore};

pub fn list_plugins(store: &AppStore) -> AppResult<Vec<PluginSummary>> {
    let discovered = discover_plugins();
    let existing = store.plugins()?;
    let enabled_by_id = existing
        .iter()
        .map(|plugin| (plugin.id.clone(), plugin.enabled))
        .collect::<HashMap<_, _>>();

    let mut merged = discovered
        .into_iter()
        .map(|mut plugin| {
            if let Some(enabled) = enabled_by_id.get(&plugin.id) {
                plugin.enabled = *enabled;
            }
            plugin
        })
        .collect::<Vec<_>>();
    merged.sort_by(|a, b| a.name.cmp(&b.name));
    store.set_plugins(merged)
}

pub fn toggle_plugin(
    store: &AppStore,
    plugin_id: &str,
    enabled: bool,
) -> AppResult<Vec<PluginSummary>> {
    if store.plugins()?.iter().all(|plugin| plugin.id != plugin_id) {
        let _ = list_plugins(store)?;
    }
    store.set_plugin_enabled(plugin_id, enabled)
}

fn discover_plugins() -> Vec<PluginSummary> {
    let mut plugins = Vec::new();
    let mut seen = HashSet::new();
    for root in discover_plugin_roots() {
        for manifest in find_plugin_manifests(&root) {
            if let Some(plugin) = parse_plugin_manifest(&root, &manifest) {
                if seen.insert(plugin.id.clone()) {
                    plugins.push(plugin);
                }
            }
        }
    }
    plugins
}

fn discover_plugin_roots() -> Vec<PathBuf> {
    let mut roots = Vec::new();
    if let Ok(current) = std::env::current_dir() {
        roots.push(current.join("plugins"));
        roots.push(current.join("..").join("plugins"));
        roots.push(
            current
                .join("..")
                .join("..")
                .join("hermes-agent")
                .join("plugins"),
        );
    }
    roots.push(PathBuf::from(
        r"D:\pro_sunner\demo_vscode\hermes-agent\plugins",
    ));

    let mut seen = HashSet::new();
    roots
        .into_iter()
        .filter_map(|path| path.canonicalize().ok())
        .filter(|path| path.is_dir() && seen.insert(path.clone()))
        .collect()
}

fn find_plugin_manifests(root: &Path) -> Vec<PathBuf> {
    let mut manifests = Vec::new();
    let mut stack = vec![root.to_path_buf()];
    while let Some(dir) = stack.pop() {
        let Ok(entries) = fs::read_dir(&dir) else {
            continue;
        };
        for entry in entries.flatten() {
            let path = entry.path();
            if path.is_dir() {
                stack.push(path);
                continue;
            }
            let name = path
                .file_name()
                .and_then(|value| value.to_str())
                .unwrap_or("");
            if matches!(name, "plugin.yaml" | "plugin.yml" | "manifest.json") {
                manifests.push(path);
            }
        }
    }
    manifests
}

fn parse_plugin_manifest(root: &Path, manifest: &Path) -> Option<PluginSummary> {
    let raw = fs::read_to_string(manifest).ok()?;
    let rel = manifest
        .parent()
        .unwrap_or(manifest)
        .strip_prefix(root)
        .unwrap_or(manifest);
    let fallback_id = path_id(rel);
    if manifest.extension().and_then(|value| value.to_str()) == Some("json") {
        let value = serde_json::from_str::<Value>(&raw).ok()?;
        let name = string_field(&value, &["label", "name"]).unwrap_or_else(|| fallback_id.clone());
        return Some(PluginSummary {
            id: string_field(&value, &["name", "id"]).unwrap_or(fallback_id),
            name,
            description: string_field(&value, &["description"]).unwrap_or_default(),
            enabled: false,
            provided_tools: vec![],
            version: string_field(&value, &["version"]).unwrap_or_default(),
            author: string_field(&value, &["author"]).unwrap_or_default(),
            source: "hermes-dashboard".into(),
            homepage_url: string_field(&value, &["homepageUrl", "homepage", "url"])
                .unwrap_or_default(),
        });
    }

    let fields = parse_simple_yaml(&raw);
    let id = fields.get("name").cloned().unwrap_or(fallback_id);
    Some(PluginSummary {
        id: id.clone(),
        name: id,
        description: fields.get("description").cloned().unwrap_or_default(),
        enabled: false,
        provided_tools: parse_yaml_list(&raw, "provides_tools"),
        version: fields.get("version").cloned().unwrap_or_default(),
        author: fields.get("author").cloned().unwrap_or_default(),
        source: "hermes-plugin".into(),
        homepage_url: fields
            .get("homepage")
            .or_else(|| fields.get("homepage_url"))
            .cloned()
            .unwrap_or_default(),
    })
}

fn parse_simple_yaml(raw: &str) -> HashMap<String, String> {
    let mut fields = HashMap::new();
    for line in raw.lines() {
        let trimmed = line.trim();
        if trimmed.is_empty() || trimmed.starts_with('#') || trimmed.starts_with('-') {
            continue;
        }
        let Some((key, value)) = trimmed.split_once(':') else {
            continue;
        };
        let value = value.trim();
        if value.is_empty() || value.starts_with('[') {
            continue;
        }
        fields.insert(key.trim().to_string(), clean_scalar(value));
    }
    fields
}

fn parse_yaml_list(raw: &str, key: &str) -> Vec<String> {
    let mut items = Vec::new();
    let mut in_list = false;
    for line in raw.lines() {
        let trimmed = line.trim();
        if trimmed.starts_with(&format!("{key}:")) {
            in_list = true;
            if let Some((_, inline)) = trimmed.split_once(':') {
                let inline = inline.trim();
                if inline.starts_with('[') && inline.ends_with(']') {
                    return inline
                        .trim_matches(|ch| ch == '[' || ch == ']')
                        .split(',')
                        .map(clean_scalar)
                        .filter(|value| !value.is_empty())
                        .collect();
                }
            }
            continue;
        }
        if in_list {
            if let Some(item) = trimmed.strip_prefix('-') {
                let item = clean_scalar(item.trim());
                if !item.is_empty() {
                    items.push(item);
                }
                continue;
            }
            if !trimmed.is_empty() && !line.starts_with(' ') && !line.starts_with('\t') {
                break;
            }
        }
    }
    items
}

fn string_field(value: &Value, keys: &[&str]) -> Option<String> {
    keys.iter()
        .find_map(|key| value.get(*key).and_then(Value::as_str))
        .map(ToOwned::to_owned)
}

fn clean_scalar(value: &str) -> String {
    value
        .trim()
        .trim_matches('"')
        .trim_matches('\'')
        .to_string()
}

fn path_id(path: &Path) -> String {
    path.components()
        .filter_map(|component| component.as_os_str().to_str())
        .map(|part| {
            part.chars()
                .map(|ch| {
                    if ch.is_ascii_alphanumeric() {
                        ch.to_ascii_lowercase()
                    } else {
                        '-'
                    }
                })
                .collect::<String>()
        })
        .collect::<Vec<_>>()
        .join("/")
}

use chrono::Utc;
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};

pub fn now_iso() -> String {
    Utc::now().to_rfc3339()
}

pub fn new_id(prefix: &str) -> String {
    format!("{prefix}-{}", uuid::Uuid::new_v4().simple())
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
#[serde(default)]
pub struct AppConfig {
    pub log_level: String,
    pub chat: ChatConfig,
    pub reply: Value,
    pub web: Value,
    pub weather: Value,
    pub homeassistant: Value,
    pub feishu: Value,
    pub yuanbao: Value,
    pub spotify: Value,
    pub discord: Value,
    pub moments: Value,
    pub video_summary: Value,
    pub telemetry_enabled: bool,
}

impl Default for AppConfig {
    fn default() -> Self {
        Self {
            log_level: "info".into(),
            chat: ChatConfig::default(),
            reply: json!({
                "typingDelayEnabled": true,
                "typingSpeed": 0.2,
                "typingSpeedRandomMin": 0.05,
                "typingSpeedRandomMax": 0.1,
                "splitByNewline": true,
                "showTypingIndicator": true
            }),
            web: json!({"port": 62000, "password": "", "publicEnabled": false, "publicPort": 0, "publicSecret": ""}),
            weather: json!({"defaultLocation": "", "qweatherApiHost": "", "qweatherApiKey": "", "timeoutSeconds": 15}),
            homeassistant: json!({"enabled": false, "url": "http://homeassistant.local:8123", "token": "", "timeoutSeconds": 15, "blockedDomains": ["shell_command", "command_line", "python_script", "pyscript", "hassio", "rest_command"]}),
            feishu: json!({"enabled": false, "baseUrl": "https://open.feishu.cn", "appId": "", "appSecret": "", "tenantAccessToken": "", "timeoutSeconds": 15}),
            yuanbao: json!({"enabled": false, "gatewayUrl": "", "token": "", "timeoutSeconds": 15, "paths": {}, "stickers": []}),
            spotify: json!({"enabled": false, "apiBaseUrl": "https://api.spotify.com/v1", "accessToken": "", "refreshToken": "", "clientId": "", "clientSecret": "", "tokenUrl": "https://accounts.spotify.com/api/token", "timeoutSeconds": 15}),
            discord: json!({"enabled": false, "apiBaseUrl": "https://discord.com/api/v10", "botToken": "", "gatewayUrl": "", "paths": {}, "timeoutSeconds": 15}),
            moments: json!({"autoReplyEnabled": false, "publishers": [], "repliers": []}),
            video_summary: json!({
                "enabled": false, "modelsDir": "", "transcriber": "auto", "ytDlpCommand": "yt-dlp",
                "cookie": "", "cookieFile": "", "ffmpegBinPath": "", "fasterWhisperModel": "small",
                "fasterWhisperModelDir": "", "fasterWhisperDevice": "cpu", "fasterWhisperComputeType": "int8",
                "senseVoiceModelDir": "", "senseVoiceDevice": "cpu", "timeoutSeconds": 30,
                "ytdlpInfoTimeoutSeconds": 120, "downloadTimeoutSeconds": 600, "outputDir": ""
            }),
            telemetry_enabled: false,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
#[serde(default)]
pub struct ChatConfig {
    pub skip_env_check: bool,
    pub agent_engine: String,
    pub max_context_rounds: usize,
    pub short_context_mode: String,
    pub short_context_token_budget: usize,
    pub busy_input_mode: String,
    pub auto_title_enabled: bool,
    pub queue_wait_seconds: u64,
    pub agent_run_timeout_seconds: u64,
    pub ui_message_limit: usize,
    pub artifact_scan_limit: usize,
    pub ui_message_preview_chars: usize,
    pub ui_stream_chars_per_second: usize,
    pub thinking_min_visible_ms: usize,
    pub bottom_follow_threshold_px: usize,
    pub active_poll_interval_ms: usize,
    pub idle_poll_interval_ms: usize,
    pub intent_analyzer_mode: String,
    pub tool_router_mode: String,
    pub tool_use_enforcement: String,
    pub tool_parallel_enabled: bool,
    pub tool_parallel_limit: usize,
    pub tool_approval_mode: String,
    pub trusted_tool_patterns: Vec<String>,
    pub tool_mutation_checkpoint_enabled: bool,
    pub llm_retry_count: usize,
    pub llm_retry_backoff_ms: usize,
    pub tool_call_retry_count: usize,
    pub tool_call_retry_backoff_ms: usize,
    pub tool_guardrail_exact_failure_limit: u32,
    pub tool_guardrail_same_tool_failure_limit: u32,
    pub tool_guardrail_no_progress_limit: u32,
    pub background_memory_review_enabled: bool,
    pub background_memory_review_min_messages: usize,
    pub background_skill_review_enabled: bool,
    pub background_skill_review_auto_create_enabled: bool,
    pub background_skill_curator_enabled: bool,
    pub background_skill_curator_interval_hours: usize,
    pub skill_hot_reload_enabled: bool,
    pub skill_hot_reload_interval_seconds: usize,
    pub history_cleanup_enabled: bool,
    pub history_retention_days: usize,
    pub max_stored_messages_per_conversation: usize,
    pub max_stored_agent_runs: usize,
    pub max_stored_tool_traces: usize,
}

impl Default for ChatConfig {
    fn default() -> Self {
        Self {
            skip_env_check: true,
            agent_engine: "rust_synthgraph".into(),
            max_context_rounds: 10,
            short_context_mode: "messages".into(),
            short_context_token_budget: 8000,
            busy_input_mode: "queue".into(),
            auto_title_enabled: true,
            queue_wait_seconds: 7,
            agent_run_timeout_seconds: 600,
            ui_message_limit: 180,
            artifact_scan_limit: 80,
            ui_message_preview_chars: 12000,
            ui_stream_chars_per_second: 36,
            thinking_min_visible_ms: 1800,
            bottom_follow_threshold_px: 180,
            active_poll_interval_ms: 1500,
            idle_poll_interval_ms: 3000,
            intent_analyzer_mode: "embedding".into(),
            tool_router_mode: "llm_unified".into(),
            tool_use_enforcement: "auto".into(),
            tool_parallel_enabled: true,
            tool_parallel_limit: 4,
            tool_approval_mode: "risky".into(),
            trusted_tool_patterns: vec![],
            tool_mutation_checkpoint_enabled: true,
            llm_retry_count: 2,
            llm_retry_backoff_ms: 800,
            tool_call_retry_count: 1,
            tool_call_retry_backoff_ms: 300,
            tool_guardrail_exact_failure_limit: 3,
            tool_guardrail_same_tool_failure_limit: 4,
            tool_guardrail_no_progress_limit: 2,
            background_memory_review_enabled: true,
            background_memory_review_min_messages: 4,
            background_skill_review_enabled: true,
            background_skill_review_auto_create_enabled: false,
            background_skill_curator_enabled: true,
            background_skill_curator_interval_hours: 168,
            skill_hot_reload_enabled: true,
            skill_hot_reload_interval_seconds: 3,
            history_cleanup_enabled: true,
            history_retention_days: 14,
            max_stored_messages_per_conversation: 300,
            max_stored_agent_runs: 50,
            max_stored_tool_traces: 100,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ProfileConfig {
    pub name: String,
    pub avatar_path: Option<String>,
}

impl Default for ProfileConfig {
    fn default() -> Self {
        Self {
            name: "用户".into(),
            avatar_path: Some(String::new()),
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Persona {
    pub id: String,
    pub name: String,
    pub agent_id: String,
    pub avatar_path: Option<String>,
    pub system_prompt: String,
    pub character_prompt: String,
    pub output_examples: String,
    pub system_instructions: String,
    pub llm_provider: String,
    pub llm_model: String,
    pub temperature: f32,
    pub max_tokens: u32,
    pub tool_policy: Value,
    pub emoji_enabled: bool,
    pub emoji_group: String,
    pub emoji_send_probability: u8,
    pub memory: Value,
    pub proactive: Value,
    pub voice_reply: Value,
    pub image_generation: Value,
}

impl Default for Persona {
    fn default() -> Self {
        Self {
            id: "default".into(),
            name: "小可".into(),
            agent_id: "default".into(),
            avatar_path: Some(String::new()),
            system_prompt: "你是一个友好、稳定的聊天助手。".into(),
            character_prompt: String::new(),
            output_examples: String::new(),
            system_instructions: "请始终保持角色一致性。".into(),
            llm_provider: String::new(),
            llm_model: String::new(),
            temperature: 0.8,
            max_tokens: 2048,
            tool_policy: json!({"enabled": true, "timeoutSeconds": 30, "maxIterations": 8, "maxFailureReplans": 2, "retryCount": 1, "retryBackoffMs": 300}),
            emoji_enabled: true,
            emoji_group: "default".into(),
            emoji_send_probability: 25,
            memory: json!({"enabled": true, "triggerRounds": 10, "maxMemories": 50, "includeInPrompt": true}),
            proactive: json!({"enabled": false, "minIdleHours": 1, "maxIdleHours": 3, "maxConsecutive": 3, "prompt": "", "quietHours": {"enabled": true, "start": "22:00", "end": "08:00"}}),
            voice_reply: json!({"enabled": false, "engine": "chattts", "pythonPath": "", "modelDir": "", "sampleRate": 16000, "speed": 5, "oral": 5, "laugh": 0, "breakLevel": 3, "speakerSeed": 0, "speakerEmbedding": "", "temperature": 0.3, "topP": 0.7, "topK": 20, "refineTextEnabled": true, "refinePrompt": "", "refineTemperature": 0.7}),
            image_generation: json!({"enabled": false, "provider": "", "model": "", "stylePrefix": "", "artStyle": "", "negativePrompt": "", "negativeEnabled": false, "refMode": "avatar"}),
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Conversation {
    pub id: String,
    pub title: String,
    pub updated_at: String,
    pub last_message: String,
    pub persona_id: Option<String>,
    pub wechat_account_id: Option<String>,
    pub agent_id: String,
    pub created_at: String,
}

impl Conversation {
    pub fn new(title: String, persona_id: String, agent_id: String) -> Self {
        let now = now_iso();
        Self {
            id: new_id("conv"),
            title,
            updated_at: now.clone(),
            last_message: String::new(),
            persona_id: Some(persona_id),
            wechat_account_id: None,
            agent_id,
            created_at: now,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ChatMessage {
    pub id: String,
    pub conversation_id: String,
    pub role: String,
    pub content: String,
    pub created_at: String,
    pub source: String,
    pub account_id: Option<String>,
}

impl ChatMessage {
    pub fn new(conversation_id: String, role: &str, content: String, source: &str) -> Self {
        Self {
            id: new_id("msg"),
            conversation_id,
            role: role.into(),
            content,
            created_at: now_iso(),
            source: source.into(),
            account_id: None,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SendChatRequest {
    pub conversation_id: Option<String>,
    pub persona_id: Option<String>,
    pub content: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct LlmProvider {
    pub id: String,
    pub name: String,
    pub provider_type: String,
    pub preset: Option<String>,
    pub base_url: String,
    pub append_chat_path: bool,
    pub api_key_env: String,
    pub api_key: Option<String>,
    pub model: String,
    pub enabled: bool,
    pub timeout_seconds: u64,
    #[serde(default = "default_prompt_cache_mode")]
    pub prompt_cache_mode: String,
    #[serde(default = "default_prompt_cache_ttl")]
    pub prompt_cache_ttl: String,
    #[serde(default = "default_prompt_cache_layout")]
    pub prompt_cache_layout: String,
}

impl Default for LlmProvider {
    fn default() -> Self {
        Self {
            id: "local-echo".into(),
            name: "本地回显".into(),
            provider_type: "echo".into(),
            preset: Some("echo".into()),
            base_url: String::new(),
            append_chat_path: true,
            api_key_env: String::new(),
            api_key: None,
            model: "echo".into(),
            enabled: true,
            timeout_seconds: 60,
            prompt_cache_mode: default_prompt_cache_mode(),
            prompt_cache_ttl: default_prompt_cache_ttl(),
            prompt_cache_layout: default_prompt_cache_layout(),
        }
    }
}

fn default_prompt_cache_mode() -> String {
    "auto".into()
}

fn default_prompt_cache_ttl() -> String {
    "5m".into()
}

fn default_prompt_cache_layout() -> String {
    "auto".into()
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct VisionProvider {
    pub id: String,
    pub name: String,
    pub provider_type: String,
    pub base_url: String,
    pub api_key_env: String,
    pub api_key: Option<String>,
    pub model: String,
    pub enabled: bool,
    pub timeout_seconds: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SearchProvider {
    pub id: String,
    pub name: String,
    pub provider_type: String,
    pub base_url: String,
    pub enabled: bool,
    pub timeout_seconds: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ImageProvider {
    pub id: String,
    pub name: String,
    pub provider_type: String,
    pub base_url: String,
    pub api_key_env: String,
    pub api_key: Option<String>,
    pub model: String,
    pub enabled: bool,
    pub timeout_seconds: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct VideoProvider {
    pub id: String,
    pub name: String,
    pub provider_type: String,
    pub base_url: String,
    pub api_key_env: String,
    pub api_key: Option<String>,
    pub model: String,
    pub enabled: bool,
    pub timeout_seconds: u64,
    #[serde(default)]
    pub submit_path: String,
    #[serde(default)]
    pub status_path: String,
    #[serde(default)]
    pub id_path: String,
    #[serde(default)]
    pub status_field: String,
    #[serde(default)]
    pub result_path: String,
    #[serde(default)]
    pub completed_statuses: Vec<String>,
    #[serde(default)]
    pub failed_statuses: Vec<String>,
    #[serde(default)]
    pub poll_interval_seconds: u64,
    #[serde(default)]
    pub max_poll_seconds: u64,
    #[serde(default)]
    pub download_result: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct BrowserProvider {
    pub id: String,
    pub name: String,
    pub provider_type: String,
    pub base_url: String,
    pub api_key_env: String,
    pub api_key: Option<String>,
    #[serde(default)]
    pub project_id: String,
    pub enabled: bool,
    pub timeout_seconds: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AgentDefinition {
    pub id: String,
    pub name: String,
    pub description: String,
    pub workspace_dir: String,
    pub llm_provider: String,
    pub llm_model: String,
    pub enabled: bool,
    pub is_default: bool,
    pub mcp_enabled: bool,
    pub skills_enabled: bool,
    pub allow_shell: bool,
    pub max_subagents: u32,
    #[serde(default = "default_max_subagent_depth")]
    pub max_subagent_depth: u32,
    pub max_tool_iterations: u32,
    pub skills_dir: String,
    pub enabled_skills: Vec<String>,
    pub enabled_mcp_servers: Vec<String>,
    #[serde(default)]
    pub enabled_toolsets: Vec<String>,
    #[serde(default)]
    pub disabled_toolsets: Vec<String>,
    pub created_at: String,
    pub updated_at: String,
}

fn default_max_subagent_depth() -> u32 {
    1
}

impl Default for AgentDefinition {
    fn default() -> Self {
        let now = now_iso();
        Self {
            id: "default".into(),
            name: "默认智能体".into(),
            description: "SynthChat Rust 对话智能体".into(),
            workspace_dir: String::new(),
            llm_provider: String::new(),
            llm_model: String::new(),
            enabled: true,
            is_default: true,
            mcp_enabled: true,
            skills_enabled: true,
            allow_shell: false,
            max_subagents: 4,
            max_subagent_depth: default_max_subagent_depth(),
            max_tool_iterations: 90,
            skills_dir: String::new(),
            enabled_skills: vec![],
            enabled_mcp_servers: vec![],
            enabled_toolsets: vec![],
            disabled_toolsets: vec![],
            created_at: now.clone(),
            updated_at: now,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct EnhancedSkillSummary {
    pub id: String,
    pub name: String,
    pub description: String,
    pub enabled: bool,
    pub path: String,
    pub version: String,
    pub author: String,
    pub icon: String,
    pub is_core: bool,
    pub is_bundled: bool,
    pub source: String,
    pub agent_id: String,
    pub config: std::collections::HashMap<String, String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SkillBundle {
    pub id: String,
    pub name: String,
    pub description: String,
    pub skill_ids: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct MarketplaceSkill {
    pub id: String,
    pub name: String,
    pub description: String,
    pub version: String,
    pub author: String,
    pub download_url: String,
    pub icon: String,
    pub tags: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SkillAuditFinding {
    pub severity: String,
    pub category: String,
    pub message: String,
    pub file: String,
    pub line: Option<usize>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SkillAuditReport {
    pub skill_id: String,
    pub name: String,
    pub path: String,
    pub status: String,
    pub checked_files: usize,
    pub findings: Vec<SkillAuditFinding>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SkillInstallRecord {
    pub skill_id: String,
    pub name: String,
    pub source: String,
    pub identifier: String,
    pub install_path: String,
    pub audit_status: String,
    pub installed_at: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "camelCase")]
pub struct SkillTap {
    pub repo: String,
    pub path: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SkillTapStatus {
    pub repo: String,
    pub path: String,
    pub status: String,
    pub entry_count: usize,
    pub detail: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SkillUpdateCheck {
    pub skill_id: String,
    pub name: String,
    pub status: String,
    pub detail: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SkillCuratorOverlap {
    pub umbrella: String,
    pub skill_ids: Vec<String>,
    pub reason: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SkillCuratorArchiveCandidate {
    pub skill_id: String,
    pub name: String,
    pub reason: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SkillCuratorReport {
    pub generated_at: String,
    pub report_path: String,
    pub total_skills: usize,
    pub external_skills: usize,
    pub bundled_skills: usize,
    pub audit_attention: usize,
    pub overlap_clusters: Vec<SkillCuratorOverlap>,
    pub archive_candidates: Vec<SkillCuratorArchiveCandidate>,
    pub recommendations: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SkillCuratorArchiveRecord {
    pub archive_id: String,
    pub skill_id: String,
    pub name: String,
    pub original_path: String,
    pub archive_path: String,
    pub reason: String,
    pub archived_at: String,
    pub restored_at: Option<String>,
    pub install_record: SkillInstallRecord,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SkillCuratorState {
    pub paused: bool,
    pub pinned_skill_ids: Vec<String>,
    pub archived: Vec<SkillCuratorArchiveRecord>,
    pub last_run_at: Option<String>,
    pub last_report_path: Option<String>,
    pub run_count: usize,
    pub updated_at: String,
}

#[derive(Debug, Clone)]
pub struct SkillPromptBlock {
    pub id: String,
    pub name: String,
    pub content: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PluginSummary {
    pub id: String,
    pub name: String,
    pub description: String,
    pub enabled: bool,
    pub provided_tools: Vec<String>,
    #[serde(default)]
    pub version: String,
    #[serde(default)]
    pub author: String,
    #[serde(default)]
    pub source: String,
    #[serde(default)]
    pub homepage_url: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AgentRunRecord {
    pub run_id: String,
    pub conversation_id: String,
    pub persona_id: String,
    pub agent_id: String,
    #[serde(default)]
    pub parent_run_id: Option<String>,
    #[serde(default)]
    pub subagent_index: Option<u32>,
    #[serde(default)]
    pub subagent_depth: Option<u32>,
    #[serde(default)]
    pub subagent_can_delegate: Option<bool>,
    #[serde(default)]
    pub subagent_role: Option<String>,
    #[serde(default)]
    pub subagent_task: Option<String>,
    #[serde(default)]
    pub subagent_toolsets: Vec<String>,
    #[serde(default)]
    pub user_request: String,
    pub state: String,
    pub started_at: String,
    pub updated_at: String,
    pub completed_at: Option<String>,
    pub error: Option<String>,
    #[serde(default)]
    pub tool_events: Vec<Value>,
    #[serde(default)]
    pub phase_events: Vec<AgentRunPhaseRecord>,
    #[serde(default)]
    pub checkpoints: Vec<AgentCheckpointRecord>,
    #[serde(default)]
    pub pending_steers: Vec<String>,
}

impl AgentRunRecord {
    pub fn new(conversation_id: String, persona_id: String, agent_id: String) -> Self {
        let now = now_iso();
        Self {
            run_id: new_id("run"),
            conversation_id,
            persona_id,
            agent_id,
            parent_run_id: None,
            subagent_index: None,
            subagent_depth: None,
            subagent_can_delegate: None,
            subagent_role: None,
            subagent_task: None,
            subagent_toolsets: vec![],
            user_request: String::new(),
            state: "started".into(),
            started_at: now.clone(),
            updated_at: now,
            completed_at: None,
            error: None,
            tool_events: vec![],
            phase_events: vec![],
            checkpoints: vec![],
            pending_steers: vec![],
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AgentQueuedRequest {
    pub id: String,
    pub conversation_id: String,
    pub persona_id: String,
    pub user_message_id: String,
    pub content: String,
    pub status: String,
    pub created_at: String,
    pub updated_at: String,
    pub started_at: Option<String>,
    pub completed_at: Option<String>,
    pub error: Option<String>,
}

impl AgentQueuedRequest {
    pub fn new(conversation_id: String, persona_id: String, user_message: &ChatMessage) -> Self {
        let now = now_iso();
        Self {
            id: new_id("queue"),
            conversation_id,
            persona_id,
            user_message_id: user_message.id.clone(),
            content: user_message.content.clone(),
            status: "pending".into(),
            created_at: now.clone(),
            updated_at: now,
            started_at: None,
            completed_at: None,
            error: None,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
#[serde(default)]
pub struct ScheduledAgentJob {
    pub id: String,
    pub name: String,
    pub conversation_id: Option<String>,
    pub persona_id: String,
    pub prompt: String,
    pub schedule_kind: String,
    pub interval_minutes: Option<u64>,
    pub cron_expr: Option<String>,
    pub run_at: Option<String>,
    pub enabled_toolsets: Vec<String>,
    pub disabled_toolsets: Vec<String>,
    pub enabled: bool,
    pub status: String,
    pub next_run_at: Option<String>,
    pub last_run_at: Option<String>,
    pub last_completed_at: Option<String>,
    pub last_run_status: Option<String>,
    pub last_output: Option<String>,
    pub last_output_path: Option<String>,
    pub last_error: Option<String>,
    pub run_count: u64,
    pub created_at: String,
    pub updated_at: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ScheduledJobOutputRecord {
    pub file_name: String,
    pub path: String,
    pub modified_at: String,
    pub size_bytes: u64,
    pub status: String,
}

impl Default for ScheduledAgentJob {
    fn default() -> Self {
        let now = now_iso();
        Self {
            id: String::new(),
            name: String::new(),
            conversation_id: None,
            persona_id: "default".into(),
            prompt: String::new(),
            schedule_kind: "once".into(),
            interval_minutes: None,
            cron_expr: None,
            run_at: None,
            enabled_toolsets: vec![],
            disabled_toolsets: vec![],
            enabled: true,
            status: "scheduled".into(),
            next_run_at: None,
            last_run_at: None,
            last_completed_at: None,
            last_run_status: None,
            last_output: None,
            last_output_path: None,
            last_error: None,
            run_count: 0,
            created_at: now.clone(),
            updated_at: now,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AgentTodoItem {
    pub id: String,
    pub run_id: String,
    pub conversation_id: String,
    pub content: String,
    pub status: String,
    pub created_at: String,
    pub updated_at: String,
}

impl AgentTodoItem {
    pub fn new(run_id: String, conversation_id: String, content: String, status: String) -> Self {
        let now = now_iso();
        Self {
            id: new_id("todo"),
            run_id,
            conversation_id,
            content,
            status,
            created_at: now.clone(),
            updated_at: now,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AgentRunPhaseRecord {
    pub phase: String,
    pub detail: Value,
    pub updated_at: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AgentCheckpointRecord {
    pub checkpoint_id: String,
    pub run_id: String,
    pub iteration: u32,
    pub created_at: String,
    pub state: String,
    #[serde(default)]
    pub completed_call_ids: Vec<String>,
    #[serde(default)]
    pub event_refs: Vec<String>,
    pub summary: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct MemoryEntry {
    pub id: String,
    pub persona_id: String,
    pub summary: String,
    pub importance: u8,
    pub created_at: String,
    pub updated_at: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct MemoryStatus {
    pub persona_id: String,
    pub persona_name: String,
    pub enabled: bool,
    pub include_in_prompt: bool,
    pub trigger_rounds: u64,
    pub max_memories: u64,
    pub total: usize,
    pub prompt_safe: usize,
    pub blocked_by_security_scan: usize,
    pub prompt_injected: usize,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ShortContextState {
    pub conversation_id: String,
    pub boundary_id: Option<String>,
    pub summary: String,
    pub summary_tokens: usize,
    pub summary_messages: usize,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct McpServer {
    pub id: String,
    pub name: String,
    pub transport: Option<String>,
    pub command: String,
    pub args: Vec<String>,
    pub env: Option<std::collections::HashMap<String, String>>,
    pub url: Option<String>,
    pub protocol: String,
    pub enabled: bool,
    pub timeout_seconds: u64,
    #[serde(default, alias = "supports_parallel_tool_calls")]
    pub supports_parallel_tool_calls: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct CapabilityAdapter {
    pub name: String,
    pub description: String,
    pub mcp_server: String,
    pub mcp_tool: String,
    pub parameters: Value,
    pub param_mapping: std::collections::HashMap<String, String>,
    pub inject_fields: std::collections::HashMap<String, String>,
    pub enabled: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct McpToolInfo {
    pub name: String,
    pub description: Option<String>,
    pub input_schema: Option<Value>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct McpListToolsResult {
    pub ok: bool,
    pub timed_out: bool,
    pub elapsed_ms: u128,
    pub tools: Vec<McpToolInfo>,
    pub raw: Option<Value>,
    pub error: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct McpCallResult {
    pub ok: bool,
    pub timed_out: bool,
    pub elapsed_ms: u128,
    pub stdout: String,
    pub stderr: String,
    pub error: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ToolEvent {
    pub status: Option<String>,
    pub reference_id: Option<String>,
    pub call_id: Option<String>,
    pub run_id: Option<String>,
    pub checkpoint_id: Option<String>,
    pub event_type: String,
    pub server_id: String,
    pub tool_name: String,
    pub ok: bool,
    pub timed_out: bool,
    pub elapsed_ms: u128,
    #[serde(default = "default_tool_event_kind")]
    pub kind: String,
    pub title: String,
    pub summary: String,
    pub path: Option<String>,
    pub exists: Option<bool>,
    pub mime_type: Option<String>,
    pub text: Option<String>,
    pub error: Option<String>,
    pub raw: Option<Value>,
}

fn default_tool_event_kind() -> String {
    "other".into()
}

pub fn tool_event_kind(server_id: &str, tool_name: &str, description: Option<&str>) -> String {
    let name = tool_name.to_lowercase();
    match name.as_str() {
        "tool_describe"
        | "read_file"
        | "browser_snapshot"
        | "browser_vision"
        | "browser_get_images"
        | "transcribe_audio"
        | "vision_analyze"
        | "video_analyze"
        | "skill_view"
        | "skills_list"
        | "recall_memory"
        | "session_search"
        | "manage_memory"
        | "memory"
        | "kanban_show"
        | "kanban_list"
        | "ha_list_entities"
        | "ha_get_state"
        | "ha_list_services"
        | "feishu_doc_read"
        | "feishu_drive_list_comments"
        | "feishu_drive_list_comment_replies"
        | "yb_query_group_info"
        | "yb_query_group_members"
        | "spotify_albums"
        | "discord"
        | "browser_supervisor_state" => return "read".into(),
        "write_file"
        | "patch"
        | "skill_manage"
        | "remember_fact"
        | "cronjob"
        | "send_message"
        | "update_todo"
        | "ha_call_service"
        | "kanban_create"
        | "kanban_complete"
        | "kanban_block"
        | "kanban_unblock"
        | "kanban_heartbeat"
        | "kanban_comment"
        | "kanban_link"
        | "feishu_drive_reply_comment"
        | "feishu_drive_add_comment"
        | "yb_send_dm"
        | "yb_send_sticker"
        | "discord_admin" => return "edit".into(),
        "tool_search" | "search_files" | "web_search" | "x_search" | "yb_search_sticker"
        | "spotify_search" => return "search".into(),
        "web_extract" | "browser_navigate" | "browser_cdp" | "weather" => return "fetch".into(),
        "terminal"
        | "tool_call"
        | "shell"
        | "process"
        | "execute_code"
        | "workspace_diagnostics"
        | "computer_use"
        | "spotify_playback"
        | "spotify_devices"
        | "spotify_queue"
        | "spotify_playlists"
        | "spotify_library"
        | "browser_click"
        | "browser_type"
        | "browser_press"
        | "browser_scroll"
        | "browser_back"
        | "delegate_task"
        | "mixture_of_agents"
        | "image_generate"
        | "video_generate"
        | "text_to_speech"
        | "clarify" => return "execute".into(),
        "_thinking" => return "think".into(),
        _ => {}
    }
    let text = format!(
        "{} {} {}",
        server_id.to_lowercase(),
        name,
        description.unwrap_or("").to_lowercase()
    );
    if text.contains("search") || text.contains("find") || text.contains("query") {
        "search".into()
    } else if text.contains("read")
        || text.contains("list")
        || text.contains("get")
        || text.contains("snapshot")
        || text.contains("inspect")
    {
        "read".into()
    } else if text.contains("write")
        || text.contains("edit")
        || text.contains("patch")
        || text.contains("delete")
        || text.contains("remove")
        || text.contains("save")
    {
        "edit".into()
    } else if text.contains("http")
        || text.contains("web")
        || text.contains("url")
        || text.contains("fetch")
    {
        "fetch".into()
    } else if text.contains("exec") || text.contains("command") || text.contains("run") {
        "execute".into()
    } else {
        "other".into()
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ToolTraceEntry {
    pub id: String,
    pub created_at: String,
    pub server_id: String,
    pub tool_name: String,
    pub ok: bool,
    pub timed_out: bool,
    pub elapsed_ms: u128,
    pub payload: Value,
    pub event: ToolEvent,
    pub error: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ToolDefinition {
    pub name: String,
    pub display_name: String,
    pub description: String,
    pub source: String,
    pub server_id: String,
    pub tool_name: String,
    pub input_schema: Value,
    pub requires_approval: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ToolApprovalRequest {
    pub id: String,
    pub created_at: String,
    pub updated_at: String,
    pub status: String,
    pub conversation_id: Option<String>,
    pub persona_id: Option<String>,
    pub agent_id: Option<String>,
    pub run_id: Option<String>,
    pub server_id: String,
    pub tool_name: String,
    pub payload: Value,
    pub reason: String,
    pub result: Option<Value>,
    pub error: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PlannerTraceRecord {
    pub id: String,
    pub run_id: String,
    pub conversation_id: String,
    pub persona_id: String,
    pub agent_id: String,
    pub iteration: u32,
    pub created_at: String,
    pub input: String,
    pub output: String,
    pub parsed_step: String,
    pub error: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ToolRouterTraceRecord {
    pub id: String,
    pub created_at: String,
    pub conversation_id: String,
    pub persona_id: String,
    pub agent_id: String,
    pub semantic_intent: String,
    pub user_request: String,
    pub prompt: String,
    pub output: String,
    pub decision: Option<Value>,
    pub status: String,
    pub error: Option<String>,
}

use std::{process::Stdio, time::Instant};

use serde_json::{json, Value};
use tokio::{
    io::{AsyncBufReadExt, AsyncWriteExt, BufReader},
    process::Command,
    time::{timeout, Duration},
};

use crate::{
    error::{AppError, AppResult},
    models::{
        new_id, now_iso, tool_event_kind, McpCallResult, McpListToolsResult, McpServer,
        McpToolInfo, ToolDefinition, ToolEvent, ToolTraceEntry,
    },
    store::AppStore,
};

pub async fn list_tools(
    store: &AppStore,
    server_id: String,
    timeout_seconds: Option<u64>,
) -> AppResult<McpListToolsResult> {
    let server = get_server(store, &server_id)?;
    let started = Instant::now();
    let timeout_secs = timeout_seconds.unwrap_or(server.timeout_seconds).max(1);
    let result = timeout(Duration::from_secs(timeout_secs), async {
        if server.protocol == "oneShotJson" {
            one_shot_json(&server, json!({"method": "tools/list", "params": {}})).await
        } else {
            mcp_json_rpc_tools_list(&server).await
        }
    })
    .await;

    let elapsed_ms = started.elapsed().as_millis();
    let response = match result {
        Ok(Ok(raw)) => {
            let tools = parse_tools(&raw);
            let definitions = tools
                .iter()
                .map(|tool| ToolDefinition {
                    name: format!("{}.{}", server.id, tool.name),
                    display_name: tool.name.clone(),
                    description: tool.description.clone().unwrap_or_default(),
                    source: "mcp".into(),
                    server_id: server.id.clone(),
                    tool_name: tool.name.clone(),
                    input_schema: tool
                        .input_schema
                        .clone()
                        .unwrap_or_else(|| json!({"type": "object"})),
                    requires_approval: requires_approval(&tool.name, tool.description.as_deref()),
                })
                .collect::<Vec<_>>();
            merge_tool_definitions(store, &server.id, definitions)?;
            McpListToolsResult {
                ok: true,
                timed_out: false,
                elapsed_ms,
                tools,
                raw: Some(raw),
                error: None,
            }
        }
        Ok(Err(error)) => McpListToolsResult {
            ok: false,
            timed_out: false,
            elapsed_ms,
            tools: vec![],
            raw: None,
            error: Some(error.to_string()),
        },
        Err(_) => McpListToolsResult {
            ok: false,
            timed_out: true,
            elapsed_ms,
            tools: vec![],
            raw: None,
            error: Some(format!("timed out after {timeout_secs}s")),
        },
    };
    Ok(response)
}

pub async fn call_tool(
    store: &AppStore,
    server_id: String,
    tool_name: String,
    payload: Value,
    timeout_seconds: Option<u64>,
) -> AppResult<McpCallResult> {
    let server = get_server(store, &server_id)?;
    let started = Instant::now();
    let timeout_secs = timeout_seconds.unwrap_or(server.timeout_seconds).max(1);
    let result = timeout(Duration::from_secs(timeout_secs), async {
        if server.protocol == "oneShotJson" {
            one_shot_json(&server, json!({"method": tool_name, "params": payload})).await
        } else {
            mcp_json_rpc_call(&server, &tool_name, payload.clone()).await
        }
    })
    .await;
    let elapsed_ms = started.elapsed().as_millis();

    let (ok, timed_out, stdout, stderr, error, raw) = match result {
        Ok(Ok(raw)) => (true, false, raw.to_string(), String::new(), None, Some(raw)),
        Ok(Err(error)) => (
            false,
            false,
            String::new(),
            error.to_string(),
            Some(error.to_string()),
            None,
        ),
        Err(_) => (
            false,
            true,
            String::new(),
            String::new(),
            Some(format!("timed out after {timeout_secs}s")),
            None,
        ),
    };

    let event = ToolEvent {
        status: Some("completed".into()),
        reference_id: None,
        call_id: Some(new_id("call")),
        run_id: None,
        checkpoint_id: None,
        event_type: "mcp_tool".into(),
        server_id: server.id.clone(),
        tool_name: tool_name.clone(),
        ok,
        timed_out,
        elapsed_ms,
        kind: tool_event_kind(&server.id, &tool_name, None),
        title: format!("{} · {}", server.name, tool_name),
        summary: if ok {
            "工具调用完成".into()
        } else {
            error.clone().unwrap_or_else(|| "工具调用失败".into())
        },
        path: None,
        exists: None,
        mime_type: None,
        text: if stdout.is_empty() {
            None
        } else {
            Some(stdout.clone())
        },
        error: error.clone(),
        raw,
    };
    store.append_tool_trace(ToolTraceEntry {
        id: new_id("trace"),
        created_at: now_iso(),
        server_id: server.id,
        tool_name,
        ok,
        timed_out,
        elapsed_ms,
        payload,
        event,
        error: error.clone(),
    })?;

    Ok(McpCallResult {
        ok,
        timed_out,
        elapsed_ms,
        stdout,
        stderr,
        error,
    })
}

pub async fn refresh_tool_registry(store: &AppStore) -> AppResult<Vec<ToolDefinition>> {
    let servers = mcp_servers(store)?;
    let mut definitions = vec![];
    for server in servers.into_iter().filter(|server| server.enabled) {
        if let Ok(result) = list_tools(store, server.id.clone(), Some(server.timeout_seconds)).await
        {
            for tool in result.tools {
                let description = tool.description.clone().unwrap_or_default();
                let requires_approval = requires_approval(&tool.name, Some(&description));
                definitions.push(ToolDefinition {
                    name: format!("{}.{}", server.id, tool.name),
                    display_name: tool.name.clone(),
                    description,
                    source: "mcp".into(),
                    server_id: server.id.clone(),
                    tool_name: tool.name,
                    input_schema: tool
                        .input_schema
                        .unwrap_or_else(|| json!({"type": "object"})),
                    requires_approval,
                });
            }
        }
    }
    definitions.extend(capability_tool_definitions(store)?);
    store.set_tool_definitions(definitions)
}

fn capability_tool_definitions(store: &AppStore) -> AppResult<Vec<ToolDefinition>> {
    Ok(store
        .capability_adapters()?
        .into_iter()
        .filter(|adapter| adapter.enabled)
        .map(|adapter| {
            let requires_approval = requires_approval(&adapter.name, Some(&adapter.description));
            ToolDefinition {
                name: adapter.name.clone(),
                display_name: adapter.name,
                description: adapter.description,
                source: "capability".into(),
                server_id: adapter.mcp_server,
                tool_name: adapter.mcp_tool,
                input_schema: adapter.parameters,
                requires_approval,
            }
        })
        .collect())
}

fn requires_approval(tool_name: &str, description: Option<&str>) -> bool {
    let haystack = format!("{} {}", tool_name, description.unwrap_or_default()).to_lowercase();
    let safe_read = [
        "snapshot", "list", "read", "get", "search", "query", "find", "inspect", "open", "fetch",
        "status", "metadata", "schema",
    ];
    if safe_read.iter().any(|keyword| haystack.contains(keyword)) {
        return false;
    }
    let high_risk = [
        "shell",
        "terminal",
        "exec",
        "execute",
        "command",
        "write",
        "patch",
        "delete",
        "remove",
        "rm",
        "move",
        "rename",
        "chmod",
        "chown",
        "kill",
        "install",
        "uninstall",
        "deploy",
        "payment",
        "email",
        "send",
        "submit",
    ];
    high_risk.iter().any(|keyword| haystack.contains(keyword))
}

fn get_server(store: &AppStore, server_id: &str) -> AppResult<McpServer> {
    mcp_servers(store)?
        .into_iter()
        .find(|server| server.id == server_id)
        .ok_or_else(|| AppError::NotFound(format!("mcp server {server_id}")))
}

fn mcp_servers(store: &AppStore) -> AppResult<Vec<McpServer>> {
    Ok(store
        .static_list("mcpServers")?
        .into_iter()
        .filter_map(|value| serde_json::from_value::<McpServer>(value).ok())
        .collect())
}

fn merge_tool_definitions(
    store: &AppStore,
    server_id: &str,
    mut definitions: Vec<ToolDefinition>,
) -> AppResult<()> {
    let mut all = store.tool_definitions()?;
    all.retain(|definition| definition.server_id != server_id);
    all.append(&mut definitions);
    store.set_tool_definitions(all)?;
    Ok(())
}

async fn one_shot_json(server: &McpServer, payload: Value) -> AppResult<Value> {
    let mut child = command(server)
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .map_err(|e| AppError::BadRequest(format!("failed to start {}: {e}", server.command)))?;

    if let Some(stdin) = child.stdin.as_mut() {
        stdin.write_all(payload.to_string().as_bytes()).await?;
        stdin.write_all(b"\n").await?;
    }

    let output = child.wait_with_output().await?;
    if !output.status.success() {
        return Err(AppError::BadRequest(
            String::from_utf8_lossy(&output.stderr).to_string(),
        ));
    }
    parse_json_stdout(&output.stdout)
}

async fn mcp_json_rpc_tools_list(server: &McpServer) -> AppResult<Value> {
    let mut child = command(server)
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .map_err(|e| AppError::BadRequest(format!("failed to start {}: {e}", server.command)))?;

    let mut stdin = child
        .stdin
        .take()
        .ok_or_else(|| AppError::BadRequest("missing mcp stdin".into()))?;
    let stdout = child
        .stdout
        .take()
        .ok_or_else(|| AppError::BadRequest("missing mcp stdout".into()))?;
    let mut lines = BufReader::new(stdout).lines();

    write_rpc(
        &mut stdin,
        1,
        "initialize",
        json!({
            "protocolVersion": "2024-11-05",
            "capabilities": {},
            "clientInfo": {"name": "SynthChat", "version": "1.0.0"}
        }),
    )
    .await?;
    read_response(&mut lines, 1).await?;
    stdin
        .write_all(
            json!({"jsonrpc":"2.0","method":"notifications/initialized","params":{}})
                .to_string()
                .as_bytes(),
        )
        .await?;
    stdin.write_all(b"\n").await?;
    write_rpc(&mut stdin, 2, "tools/list", json!({})).await?;
    let response = read_response(&mut lines, 2).await?;
    let _ = child.kill().await;
    Ok(response)
}

async fn mcp_json_rpc_call(
    server: &McpServer,
    tool_name: &str,
    payload: Value,
) -> AppResult<Value> {
    let mut child = command(server)
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .map_err(|e| AppError::BadRequest(format!("failed to start {}: {e}", server.command)))?;

    let mut stdin = child
        .stdin
        .take()
        .ok_or_else(|| AppError::BadRequest("missing mcp stdin".into()))?;
    let stdout = child
        .stdout
        .take()
        .ok_or_else(|| AppError::BadRequest("missing mcp stdout".into()))?;
    let mut lines = BufReader::new(stdout).lines();

    write_rpc(
        &mut stdin,
        1,
        "initialize",
        json!({
            "protocolVersion": "2024-11-05",
            "capabilities": {},
            "clientInfo": {"name": "SynthChat", "version": "1.0.0"}
        }),
    )
    .await?;
    read_response(&mut lines, 1).await?;
    stdin
        .write_all(
            json!({"jsonrpc":"2.0","method":"notifications/initialized","params":{}})
                .to_string()
                .as_bytes(),
        )
        .await?;
    stdin.write_all(b"\n").await?;
    write_rpc(
        &mut stdin,
        2,
        "tools/call",
        json!({"name": tool_name, "arguments": payload}),
    )
    .await?;
    let response = read_response(&mut lines, 2).await?;
    let _ = child.kill().await;
    Ok(response)
}

fn command(server: &McpServer) -> Command {
    let mut cmd = Command::new(&server.command);
    cmd.args(&server.args);
    if let Some(env) = &server.env {
        cmd.envs(env);
    }
    cmd
}

async fn write_rpc(
    stdin: &mut tokio::process::ChildStdin,
    id: u64,
    method: &str,
    params: Value,
) -> AppResult<()> {
    let line = json!({"jsonrpc": "2.0", "id": id, "method": method, "params": params}).to_string();
    stdin.write_all(line.as_bytes()).await?;
    stdin.write_all(b"\n").await?;
    stdin.flush().await?;
    Ok(())
}

async fn read_response(
    lines: &mut tokio::io::Lines<BufReader<tokio::process::ChildStdout>>,
    id: u64,
) -> AppResult<Value> {
    while let Some(line) = lines.next_line().await? {
        let trimmed = line.trim();
        if trimmed.is_empty() {
            continue;
        }
        let value: Value = serde_json::from_str(trimmed)
            .map_err(|e| AppError::BadRequest(format!("invalid mcp json: {e}; line: {trimmed}")))?;
        if value.get("id").and_then(Value::as_u64) == Some(id) {
            if let Some(error) = value.get("error") {
                return Err(AppError::BadRequest(format!("mcp error: {error}")));
            }
            return Ok(value.get("result").cloned().unwrap_or(value));
        }
    }
    Err(AppError::BadRequest(
        "mcp process exited before response".into(),
    ))
}

fn parse_json_stdout(stdout: &[u8]) -> AppResult<Value> {
    let text = String::from_utf8_lossy(stdout);
    for line in text.lines().rev() {
        let trimmed = line.trim();
        if trimmed.is_empty() {
            continue;
        }
        if let Ok(value) = serde_json::from_str(trimmed) {
            return Ok(value);
        }
    }
    Err(AppError::BadRequest(format!(
        "stdout did not contain json: {}",
        text.chars().take(500).collect::<String>()
    )))
}

fn parse_tools(raw: &Value) -> Vec<McpToolInfo> {
    let tools = raw
        .get("tools")
        .or_else(|| raw.pointer("/result/tools"))
        .and_then(Value::as_array)
        .cloned()
        .unwrap_or_default();

    tools
        .into_iter()
        .filter_map(|tool| {
            let name = tool.get("name").and_then(Value::as_str)?.to_string();
            Some(McpToolInfo {
                name,
                description: tool
                    .get("description")
                    .and_then(Value::as_str)
                    .map(ToOwned::to_owned),
                input_schema: tool
                    .get("inputSchema")
                    .or_else(|| tool.get("input_schema"))
                    .cloned(),
            })
        })
        .collect()
}
